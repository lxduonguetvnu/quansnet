const databaseOptions = {
  host: '127.0.0.1',
  user: 'root',
  password: '',
  database: 'quansnet',
};

module.exports =  databaseOptions;
